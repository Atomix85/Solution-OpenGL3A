#pragma once


class vec3 {
	public:
		float _x, _y, _z;
		vec3(float x, float y, float z);
};

class vec2 {
public:
	float _x, _y;
	vec2(float x, float y);

};